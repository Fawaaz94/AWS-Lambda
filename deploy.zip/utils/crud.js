const {instance} = require('./axiosConfig')

const putOrderList = async (ordersList) => {
    const response = await instance.put('/order', ordersList)
    .then( (res) => {
      
        // console.log(`Status Code: ${res.status}`)
        // console.log(`Status Message: ${res.statusText}`)
    })
    .catch(err => {
        console.error(err)
    })
}

module.exports = {
    putOrderList
}