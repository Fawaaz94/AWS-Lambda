const axios = require('axios').default

const instance = axios.create({
    baseURL: 'https://qgc7c2xwhg.execute-api.eu-central-1.amazonaws.com/Prod'
});
 
/* Interceptors */
instance.interceptors.request.use( response => {
    console.log("Sending request...");

    return response;
}, error => {
    return Promise.reject(error);
})

instance.interceptors.response.use( response => {
    console.log("Response successfully received:");
    console.log(`--> Status Code: ${response.status}`)
    console.log(`--> Status Message: ${response.statusText}`)

}, error => {
    return Promise.reject(error);
})

module.exports = {
    instance
}